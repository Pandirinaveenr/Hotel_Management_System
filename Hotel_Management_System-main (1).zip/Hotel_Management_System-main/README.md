# Hotel_Management_System
This system provides various options like booking a room, checking customer details, editing or deleting any customer, checking all allotted rooms. 
The project is developed using two important C++ concepts that are classes and file handling.
